import sensor, image, lcd, time
from machine import UART
from fpioa_manager import fm

lcd.init()
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.run(1)

fm.register(7, fm.fpioa.UART1_TX, force=True)
fm.register(6, fm.fpioa.UART1_RX, force=True)
uart_A = UART(UART.UART1, 115200, 8, 0, 1, timeout=1000, read_buf_len=4096)

green_threshold = (0, 80, -70, -10, -0, 30)


pixels_threshold = 100  # 可根据实际情况调整

while True:
    img = sensor.snapshot()
    blobs = img.find_blobs([green_threshold], pixels_threshold=pixels_threshold)


    num_blobs = len(blobs)
    print("", num_blobs)
    # 声明一个空字符串
    ascii_string = ""
    # 添加ASCII码值为65的字符到字符串中
    ascii_string += chr(num_blobs)
    # 将绿色色块个数通过串口发送

    print("", ascii_string)

    uart_A.write(ascii_string)

    if blobs:
        for b in blobs:
            img.draw_rectangle(b[0:4])
            img.draw_cross(b[5], b[6])

    lcd.display(img)
    time.sleep(0.3)  # 暂停一秒钟，避免过快刷新
