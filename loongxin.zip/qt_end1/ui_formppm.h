/********************************************************************************
** Form generated from reading UI file 'formppm.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMPPM_H
#define UI_FORMPPM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_FormPpm
{
public:
    QChartView *graphicsView;

    void setupUi(QWidget *FormPpm)
    {
        if (FormPpm->objectName().isEmpty())
            FormPpm->setObjectName(QString::fromUtf8("FormPpm"));
        FormPpm->resize(954, 484);
        graphicsView = new QChartView(FormPpm);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(2, 2, 950, 480));

        retranslateUi(FormPpm);

        QMetaObject::connectSlotsByName(FormPpm);
    } // setupUi

    void retranslateUi(QWidget *FormPpm)
    {
        FormPpm->setWindowTitle(QCoreApplication::translate("FormPpm", "\345\205\211\347\205\247\345\274\272\345\272\246\345\217\230\345\214\226\346\233\262\347\272\277", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormPpm: public Ui_FormPpm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMPPM_H
