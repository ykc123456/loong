/********************************************************************************
** Form generated from reading UI file 'formfire.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMFIRE_H
#define UI_FORMFIRE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_FormFire
{
public:
    QChartView *graphicsView;

    void setupUi(QWidget *FormFire)
    {
        if (FormFire->objectName().isEmpty())
            FormFire->setObjectName(QString::fromUtf8("FormFire"));
        FormFire->resize(954, 484);
        graphicsView = new QChartView(FormFire);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(2, 2, 950, 480));

        retranslateUi(FormFire);

        QMetaObject::connectSlotsByName(FormFire);
    } // setupUi

    void retranslateUi(QWidget *FormFire)
    {
        FormFire->setWindowTitle(QCoreApplication::translate("FormFire", "\345\217\221\350\212\275\347\216\207\345\217\230\345\214\226\346\233\262\347\272\277", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormFire: public Ui_FormFire {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMFIRE_H
