/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QFrame *frame_date_1;
    QTextEdit *textEdit_a_3;
    QLabel *label_date_a_3;
    QTextEdit *textEdit_a_2;
    QLabel *label_date_a_2;
    QTextEdit *textEdit_a_1;
    QLabel *label_date_a_1;
    QPushButton *set_a;
    QFrame *frame_date_2;
    QLabel *label_date_b_1;
    QLabel *label_date_b_2;
    QTextEdit *textEdit_b_1;
    QTextEdit *textEdit_b_2;
    QTextEdit *textEdit_b_3;
    QLabel *label_date_b_3;
    QPushButton *set_b;
    QFrame *frame_date_3;
    QLabel *label_date_c_1;
    QLabel *label_date_c_2;
    QTextEdit *textEdit_c_1;
    QTextEdit *textEdit_c_2;
    QTextEdit *textEdit_c_3;
    QLabel *label_date_c_3;
    QPushButton *set_c;
    QTextEdit *textEdit;
    QPushButton *pushButton_temp;
    QPushButton *pushButton_hum;
    QPushButton *pushButton_fire;
    QPushButton *pushButton_ppm;
    QLabel *label_date_4;
    QLabel *back_label;
    QPushButton *pushButton_off;
    QPushButton *pushButton_log;
    QPushButton *pushButton_history;
    QPushButton *pushButton_begin;
    QLabel *logo_label;
    QTextEdit *textEdit_c_4;
    QTextEdit *textEdit_b_4;
    QFrame *frame;
    QTextEdit *textEdit_a_4;
    QLabel *label_date_a_4;
    QLabel *label;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(900, 500);
        QFont font;
        font.setPointSize(14);
        Widget->setFont(font);
        Widget->setStyleSheet(QString::fromUtf8("QLabel#back_label\n"
"{\n"
"    \n"
"	background-image: url(:/image/mkbk.png);\n"
"}"));
        frame_date_1 = new QFrame(Widget);
        frame_date_1->setObjectName(QString::fromUtf8("frame_date_1"));
        frame_date_1->setGeometry(QRect(25, 20, 190, 240));
        frame_date_1->setStyleSheet(QString::fromUtf8(""));
        frame_date_1->setFrameShape(QFrame::StyledPanel);
        frame_date_1->setFrameShadow(QFrame::Raised);
        textEdit_a_3 = new QTextEdit(frame_date_1);
        textEdit_a_3->setObjectName(QString::fromUtf8("textEdit_a_3"));
        textEdit_a_3->setGeometry(QRect(90, 181, 90, 34));
        textEdit_a_3->setFont(font);
        label_date_a_3 = new QLabel(frame_date_1);
        label_date_a_3->setObjectName(QString::fromUtf8("label_date_a_3"));
        label_date_a_3->setGeometry(QRect(5, 183, 85, 30));
        textEdit_a_2 = new QTextEdit(frame_date_1);
        textEdit_a_2->setObjectName(QString::fromUtf8("textEdit_a_2"));
        textEdit_a_2->setGeometry(QRect(90, 126, 90, 30));
        QFont font1;
        font1.setPointSize(11);
        textEdit_a_2->setFont(font1);
        label_date_a_2 = new QLabel(frame_date_1);
        label_date_a_2->setObjectName(QString::fromUtf8("label_date_a_2"));
        label_date_a_2->setGeometry(QRect(5, 126, 85, 30));
        textEdit_a_1 = new QTextEdit(frame_date_1);
        textEdit_a_1->setObjectName(QString::fromUtf8("textEdit_a_1"));
        textEdit_a_1->setGeometry(QRect(90, 67, 90, 34));
        textEdit_a_1->setFont(font);
        label_date_a_1 = new QLabel(frame_date_1);
        label_date_a_1->setObjectName(QString::fromUtf8("label_date_a_1"));
        label_date_a_1->setGeometry(QRect(5, 69, 85, 30));
        set_a = new QPushButton(frame_date_1);
        set_a->setObjectName(QString::fromUtf8("set_a"));
        set_a->setGeometry(QRect(60, 17, 70, 30));
        set_a->setFont(font);
        set_a->setIconSize(QSize(16, 16));
        frame_date_2 = new QFrame(Widget);
        frame_date_2->setObjectName(QString::fromUtf8("frame_date_2"));
        frame_date_2->setGeometry(QRect(230, 20, 190, 240));
        frame_date_2->setStyleSheet(QString::fromUtf8(""));
        frame_date_2->setFrameShape(QFrame::StyledPanel);
        frame_date_2->setFrameShadow(QFrame::Raised);
        label_date_b_1 = new QLabel(frame_date_2);
        label_date_b_1->setObjectName(QString::fromUtf8("label_date_b_1"));
        label_date_b_1->setGeometry(QRect(5, 69, 85, 30));
        label_date_b_2 = new QLabel(frame_date_2);
        label_date_b_2->setObjectName(QString::fromUtf8("label_date_b_2"));
        label_date_b_2->setGeometry(QRect(5, 126, 85, 30));
        textEdit_b_1 = new QTextEdit(frame_date_2);
        textEdit_b_1->setObjectName(QString::fromUtf8("textEdit_b_1"));
        textEdit_b_1->setGeometry(QRect(90, 67, 90, 34));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Ubuntu"));
        font2.setPointSize(14);
        textEdit_b_1->setFont(font2);
        textEdit_b_2 = new QTextEdit(frame_date_2);
        textEdit_b_2->setObjectName(QString::fromUtf8("textEdit_b_2"));
        textEdit_b_2->setGeometry(QRect(90, 126, 90, 30));
        textEdit_b_2->setFont(font1);
        textEdit_b_3 = new QTextEdit(frame_date_2);
        textEdit_b_3->setObjectName(QString::fromUtf8("textEdit_b_3"));
        textEdit_b_3->setGeometry(QRect(90, 181, 90, 34));
        textEdit_b_3->setFont(font);
        label_date_b_3 = new QLabel(frame_date_2);
        label_date_b_3->setObjectName(QString::fromUtf8("label_date_b_3"));
        label_date_b_3->setGeometry(QRect(5, 183, 85, 30));
        set_b = new QPushButton(frame_date_2);
        set_b->setObjectName(QString::fromUtf8("set_b"));
        set_b->setGeometry(QRect(60, 17, 70, 30));
        set_b->setFont(font);
        set_b->setIconSize(QSize(16, 16));
        frame_date_3 = new QFrame(Widget);
        frame_date_3->setObjectName(QString::fromUtf8("frame_date_3"));
        frame_date_3->setGeometry(QRect(435, 20, 190, 240));
        frame_date_3->setStyleSheet(QString::fromUtf8(""));
        frame_date_3->setFrameShape(QFrame::StyledPanel);
        frame_date_3->setFrameShadow(QFrame::Raised);
        label_date_c_1 = new QLabel(frame_date_3);
        label_date_c_1->setObjectName(QString::fromUtf8("label_date_c_1"));
        label_date_c_1->setGeometry(QRect(5, 69, 85, 30));
        label_date_c_2 = new QLabel(frame_date_3);
        label_date_c_2->setObjectName(QString::fromUtf8("label_date_c_2"));
        label_date_c_2->setGeometry(QRect(5, 126, 85, 30));
        textEdit_c_1 = new QTextEdit(frame_date_3);
        textEdit_c_1->setObjectName(QString::fromUtf8("textEdit_c_1"));
        textEdit_c_1->setGeometry(QRect(90, 67, 90, 34));
        textEdit_c_1->setFont(font);
        textEdit_c_2 = new QTextEdit(frame_date_3);
        textEdit_c_2->setObjectName(QString::fromUtf8("textEdit_c_2"));
        textEdit_c_2->setGeometry(QRect(90, 126, 90, 30));
        textEdit_c_2->setFont(font1);
        textEdit_c_3 = new QTextEdit(frame_date_3);
        textEdit_c_3->setObjectName(QString::fromUtf8("textEdit_c_3"));
        textEdit_c_3->setGeometry(QRect(90, 181, 90, 34));
        textEdit_c_3->setFont(font);
        label_date_c_3 = new QLabel(frame_date_3);
        label_date_c_3->setObjectName(QString::fromUtf8("label_date_c_3"));
        label_date_c_3->setGeometry(QRect(5, 183, 85, 30));
        set_c = new QPushButton(frame_date_3);
        set_c->setObjectName(QString::fromUtf8("set_c"));
        set_c->setGeometry(QRect(60, 17, 70, 30));
        set_c->setFont(font);
        set_c->setIconSize(QSize(16, 16));
        textEdit = new QTextEdit(Widget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(310, 340, 570, 140));
        textEdit->setFont(font);
        textEdit->setStyleSheet(QString::fromUtf8(""));
        pushButton_temp = new QPushButton(Widget);
        pushButton_temp->setObjectName(QString::fromUtf8("pushButton_temp"));
        pushButton_temp->setGeometry(QRect(55, 380, 90, 40));
        pushButton_temp->setFont(font);
        pushButton_hum = new QPushButton(Widget);
        pushButton_hum->setObjectName(QString::fromUtf8("pushButton_hum"));
        pushButton_hum->setGeometry(QRect(165, 380, 90, 40));
        pushButton_hum->setFont(font);
        pushButton_fire = new QPushButton(Widget);
        pushButton_fire->setObjectName(QString::fromUtf8("pushButton_fire"));
        pushButton_fire->setGeometry(QRect(165, 440, 90, 40));
        pushButton_fire->setFont(font);
        pushButton_ppm = new QPushButton(Widget);
        pushButton_ppm->setObjectName(QString::fromUtf8("pushButton_ppm"));
        pushButton_ppm->setGeometry(QRect(55, 440, 90, 40));
        pushButton_ppm->setFont(font);
        label_date_4 = new QLabel(Widget);
        label_date_4->setObjectName(QString::fromUtf8("label_date_4"));
        label_date_4->setGeometry(QRect(85, 335, 140, 40));
        QFont font3;
        font3.setPointSize(15);
        label_date_4->setFont(font3);
        back_label = new QLabel(Widget);
        back_label->setObjectName(QString::fromUtf8("back_label"));
        back_label->setGeometry(QRect(0, 0, 900, 500));
        back_label->setStyleSheet(QString::fromUtf8("background-image: url(:/image/skc.png);"));
        pushButton_off = new QPushButton(Widget);
        pushButton_off->setObjectName(QString::fromUtf8("pushButton_off"));
        pushButton_off->setGeometry(QRect(760, 220, 90, 40));
        QFont font4;
        font4.setPointSize(14);
        font4.setBold(false);
        font4.setItalic(false);
        pushButton_off->setFont(font4);
        pushButton_log = new QPushButton(Widget);
        pushButton_log->setObjectName(QString::fromUtf8("pushButton_log"));
        pushButton_log->setGeometry(QRect(760, 280, 90, 40));
        pushButton_log->setFont(font);
        pushButton_history = new QPushButton(Widget);
        pushButton_history->setObjectName(QString::fromUtf8("pushButton_history"));
        pushButton_history->setGeometry(QRect(650, 280, 90, 40));
        pushButton_history->setFont(font);
        pushButton_begin = new QPushButton(Widget);
        pushButton_begin->setObjectName(QString::fromUtf8("pushButton_begin"));
        pushButton_begin->setGeometry(QRect(650, 220, 90, 40));
        pushButton_begin->setFont(font);
        logo_label = new QLabel(Widget);
        logo_label->setObjectName(QString::fromUtf8("logo_label"));
        logo_label->setGeometry(QRect(660, 20, 180, 180));
        logo_label->setStyleSheet(QString::fromUtf8("background-image: url(:/image/szy.png);"));
        textEdit_c_4 = new QTextEdit(Widget);
        textEdit_c_4->setObjectName(QString::fromUtf8("textEdit_c_4"));
        textEdit_c_4->setGeometry(QRect(770, 150, 15, 15));
        textEdit_b_4 = new QTextEdit(Widget);
        textEdit_b_4->setObjectName(QString::fromUtf8("textEdit_b_4"));
        textEdit_b_4->setGeometry(QRect(710, 70, 15, 15));
        frame = new QFrame(Widget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(25, 270, 600, 60));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        textEdit_a_4 = new QTextEdit(frame);
        textEdit_a_4->setObjectName(QString::fromUtf8("textEdit_a_4"));
        textEdit_a_4->setGeometry(QRect(85, 13, 80, 34));
        textEdit_a_4->setFont(font);
        label_date_a_4 = new QLabel(frame);
        label_date_a_4->setObjectName(QString::fromUtf8("label_date_a_4"));
        label_date_a_4->setGeometry(QRect(15, 15, 70, 30));
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(215, 15, 335, 30));
        QFont font5;
        font5.setPointSize(14);
        font5.setBold(true);
        font5.setItalic(true);
        label->setFont(font5);
        textEdit_b_4->raise();
        textEdit_c_4->raise();
        back_label->raise();
        frame_date_1->raise();
        frame_date_2->raise();
        frame_date_3->raise();
        textEdit->raise();
        pushButton_temp->raise();
        pushButton_hum->raise();
        pushButton_fire->raise();
        pushButton_ppm->raise();
        label_date_4->raise();
        pushButton_off->raise();
        pushButton_log->raise();
        pushButton_history->raise();
        pushButton_begin->raise();
        logo_label->raise();
        frame->raise();

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "\346\231\272\346\205\247\350\202\262\350\213\227\345\267\245\345\216\202\345\212\251\346\211\213", nullptr));
        label_date_a_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\347\205\247\345\274\272\345\272\246\357\274\232</span></p></body></html>", nullptr));
        label_date_a_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\234\237\345\243\244\346\271\277\345\272\246\357\274\232</span></p></body></html>", nullptr));
        label_date_a_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\347\216\257\345\242\203\346\270\251\345\272\246\357\274\232</span></p></body></html>", nullptr));
        set_a->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2711", nullptr));
        label_date_b_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\347\216\257\345\242\203\346\270\251\345\272\246:</span></p></body></html>", nullptr));
        label_date_b_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\234\237\345\243\244\346\271\277\345\272\246:</span></p></body></html>", nullptr));
        label_date_b_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\347\205\247\345\274\272\345\272\246\357\274\232</span></p></body></html>", nullptr));
        set_b->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2712", nullptr));
        label_date_c_1->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\347\216\257\345\242\203\346\270\251\345\272\246:</span></p></body></html>", nullptr));
        label_date_c_2->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\234\237\345\243\244\346\271\277\345\272\246:</span></p></body></html>", nullptr));
        label_date_c_3->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\205\211\347\205\247\345\274\272\345\272\246:</span></p></body></html>", nullptr));
        set_c->setText(QCoreApplication::translate("Widget", "\350\212\202\347\202\2713", nullptr));
        pushButton_temp->setText(QCoreApplication::translate("Widget", "\347\216\257\345\242\203\346\270\251\345\272\246", nullptr));
        pushButton_hum->setText(QCoreApplication::translate("Widget", "\345\234\237\345\243\244\346\271\277\345\272\246", nullptr));
        pushButton_fire->setText(QCoreApplication::translate("Widget", "\345\217\221\350\212\275\347\216\207", nullptr));
        pushButton_ppm->setText(QCoreApplication::translate("Widget", "\345\205\211\347\205\247\345\274\272\345\272\246", nullptr));
        label_date_4->setText(QCoreApplication::translate("Widget", "\347\216\257\345\242\203\345\217\202\346\225\260\346\233\262\347\272\277\345\233\276", nullptr));
        back_label->setText(QString());
        pushButton_off->setText(QCoreApplication::translate("Widget", "\345\205\263\351\227\255", nullptr));
        pushButton_log->setText(QCoreApplication::translate("Widget", "\346\227\245\345\277\227\346\237\245\350\257\242", nullptr));
        pushButton_history->setText(QCoreApplication::translate("Widget", "\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        pushButton_begin->setText(QCoreApplication::translate("Widget", "\345\274\200\345\247\213", nullptr));
        logo_label->setText(QString());
        textEdit_a_4->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:14pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;\"><br /></p></body></html>", nullptr));
        label_date_a_4->setText(QCoreApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:14pt;\">\345\217\221\350\212\275\347\216\207\357\274\232</span></p></body></html>", nullptr));
        label->setText(QCoreApplication::translate("Widget", "\346\210\221\346\227\266\345\270\270\350\247\211\345\276\227\357\274\214\346\257\217\344\270\200\345\257\270\345\205\211\351\230\264\357\274\214\351\203\275\345\274\202\345\270\270\347\264\247\350\277\253", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
