/********************************************************************************
** Form generated from reading UI file 'formhislog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHISLOG_H
#define UI_FORMHISLOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormHisLog
{
public:
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QWidget *widget;

    void setupUi(QWidget *FormHisLog)
    {
        if (FormHisLog->objectName().isEmpty())
            FormHisLog->setObjectName(QString::fromUtf8("FormHisLog"));
        FormHisLog->resize(700, 600);
        textEdit = new QTextEdit(FormHisLog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(50, 60, 600, 420));
        QFont font;
        font.setPointSize(14);
        textEdit->setFont(font);
        pushButton = new QPushButton(FormHisLog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(50, 15, 120, 30));
        pushButton->setFont(font);
        widget = new QWidget(FormHisLog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 700, 600));
        widget->setStyleSheet(QString::fromUtf8("background-image: url(:/image/zyh.png);"));
        widget->raise();
        textEdit->raise();
        pushButton->raise();

        retranslateUi(FormHisLog);

        QMetaObject::connectSlotsByName(FormHisLog);
    } // setupUi

    void retranslateUi(QWidget *FormHisLog)
    {
        FormHisLog->setWindowTitle(QCoreApplication::translate("FormHisLog", "\346\227\245\345\277\227\346\237\245\350\257\242", nullptr));
        pushButton->setText(QCoreApplication::translate("FormHisLog", "\346\270\205\351\231\244\346\227\245\345\277\227", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormHisLog: public Ui_FormHisLog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHISLOG_H
