#include "formfire.h"
#include "ui_formfire.h"

extern QList<double> data_fire_1;
// extern QList<double> data_fire_2;
// extern QList<double> data_fire_3;

FormFire::FormFire(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormFire)
{
    ui->setupUi(this);
    QChart *chart = new QChart();

    // 创建坐标轴
    QValueAxis *valueX = new QValueAxis();
    QValueAxis *valueY = new QValueAxis();

    // 设置坐标位置和范围
    valueX->setRange(0, 50000);
    valueY->setRange(0, 100); // 举例设置发芽率的范围为0到100，根据实际情况调整

    // 设置坐标轴的标题和显示格式
    valueX->setTitleText("时间/ms");
    valueY->setTitleText("发芽率/%");
    valueX->setLabelFormat("%d");
    valueY->setLabelFormat("%d");

    // 图表添加坐标轴
    chart->createDefaultAxes();
    chart->addAxis(valueX, Qt::AlignBottom);
    chart->addAxis(valueY, Qt::AlignLeft);

    // 设置标题
    chart->setTitle("发芽率变化曲线");

    // 创建曲线对象
    line_1 = new QLineSeries();
    line_1->setName("发芽率");

    // 设置图例字体
    QFont font = chart->legend()->font();
    font.setPointSizeF(14);
    chart->legend()->setFont(font);
    chart->setTitleFont(font);
    chart->legend()->setVisible(true);

    // 图表添加曲线
    chart->addSeries(line_1);

    // 将曲线的数据与坐标轴绑定
    line_1->attachAxis(valueX);
    line_1->attachAxis(valueY);

    // 将图表放置在图表视图
    ui->graphicsView->setChart(chart);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    // 设置定时器
    chart_time = new QTimer();
    chart_time->start(200); // 每200毫秒更新一次
    connect(chart_time, SIGNAL(timeout()), this, SLOT(timerTimeOut()));
}

FormFire::~FormFire()
{
    delete ui;
}

void FormFire::timerTimeOut()
{
    line_1->clear();
    int xSpace = 5000 / (51 - 1); // 计算x轴间距
    for (int i = 0; i < data_fire_1.size(); ++i) {
        line_1->append(xSpace * i, data_fire_1.at(i));
    }
}
