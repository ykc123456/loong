#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "formhum.h"
#include "formppm.h"
#include "formfire.h"
#include "formhisdata.h"
#include "formhislog.h"
#include "formtemp.h"

#include <QSerialPort>
#include <QSerialPortInfo>
#include <QJsonObject>
#include <QJsonDocument>
#include <QTimer>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    QByteArray buf;     //缓存区
    QByteArray buf_1;   //缓存区1
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_pushButton_begin_clicked();

    void serialPortReadyRead();

    void on_pushButton_off_clicked();

    void on_pushButton_temp_clicked();

    void timer_ch_1();

    void timer_ch_2();

    void timer_ch_3();

    void timer_check();

    void on_pushButton_hum_clicked();

    void on_pushButton_ppm_clicked();

    void on_pushButton_fire_clicked();

    void on_pushButton_history_clicked();

    void on_pushButton_log_clicked();

private:
    QSerialPort *serialPort;

    void openSerial();

    void dataHandle(QByteArray &data);

    void checkOnline();

    void dataTransmission(int id, double temp_x, double hum_x, double ppm_x, double fire_x);
    Ui::Widget *ui;
};
#endif // WIDGET_H
