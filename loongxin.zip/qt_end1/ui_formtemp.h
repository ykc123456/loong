/********************************************************************************
** Form generated from reading UI file 'formtemp.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMTEMP_H
#define UI_FORMTEMP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>
#include "qchartview.h"

QT_BEGIN_NAMESPACE

class Ui_FormTemp
{
public:
    QChartView *graphicsView;

    void setupUi(QWidget *FormTemp)
    {
        if (FormTemp->objectName().isEmpty())
            FormTemp->setObjectName(QString::fromUtf8("FormTemp"));
        FormTemp->resize(954, 484);
        graphicsView = new QChartView(FormTemp);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(2, 2, 950, 480));

        retranslateUi(FormTemp);

        QMetaObject::connectSlotsByName(FormTemp);
    } // setupUi

    void retranslateUi(QWidget *FormTemp)
    {
        FormTemp->setWindowTitle(QCoreApplication::translate("FormTemp", "\347\216\257\345\242\203\346\270\251\345\272\246\345\217\230\345\214\226\346\233\262\347\272\277", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormTemp: public Ui_FormTemp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMTEMP_H
