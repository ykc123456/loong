/********************************************************************************
** Form generated from reading UI file 'formhisdata.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORMHISDATA_H
#define UI_FORMHISDATA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FormHisData
{
public:
    QPushButton *pushButton;
    QTextEdit *textEdit;
    QWidget *widget;

    void setupUi(QWidget *FormHisData)
    {
        if (FormHisData->objectName().isEmpty())
            FormHisData->setObjectName(QString::fromUtf8("FormHisData"));
        FormHisData->resize(700, 600);
        pushButton = new QPushButton(FormHisData);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(25, 15, 130, 35));
        QFont font;
        font.setPointSize(14);
        pushButton->setFont(font);
        textEdit = new QTextEdit(FormHisData);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(25, 60, 650, 420));
        QFont font1;
        font1.setPointSize(13);
        textEdit->setFont(font1);
        widget = new QWidget(FormHisData);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 700, 600));
        widget->setStyleSheet(QString::fromUtf8("background-image: url(:/image/zyh.png);"));
        widget->raise();
        pushButton->raise();
        textEdit->raise();

        retranslateUi(FormHisData);

        QMetaObject::connectSlotsByName(FormHisData);
    } // setupUi

    void retranslateUi(QWidget *FormHisData)
    {
        FormHisData->setWindowTitle(QCoreApplication::translate("FormHisData", "\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        pushButton->setText(QCoreApplication::translate("FormHisData", "\346\270\205\351\231\244\345\216\206\345\217\262\350\256\260\345\275\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FormHisData: public Ui_FormHisData {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMHISDATA_H
